using System.Windows.Forms;
using static Giochi.gioco;

namespace Giochi
{
    public partial class Form1 : Form
    {

        List<gioco> giocos = new List<gioco>();

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            comboBox1.Items.Add(tiPiace.brutto);
            comboBox1.Items.Add(tiPiace.normale);
            comboBox1.Items.Add(tiPiace.carino);
            comboBox1.Items.Add(tiPiace.bello);
            comboBox1.Items.Add(tiPiace.bloodborne);
            comboBox1.SelectedItem = tiPiace.bloodborne;
            giocos.Add(new gioco("bloodborne", "fromsowtware", 2016, tiPiace.bloodborne));
            giocos.Add(new gioco("elden ring", "fromsowtware", 2022, tiPiace.bello));
            giocos.Add(new gioco("mariokart", "nintendo", 2007, tiPiace.normale));
            giocos.Add(new gioco("cyberpunk", "riot", 2018, tiPiace.bello));
            giocos.Add(new gioco("fortnite", "epicgames", 2016, tiPiace.carino));
            aggiorna_lista();
        }

        private void aggiorna_lista()
        {
            listBox1.Items.Clear();
            foreach (gioco g in giocos)
            {
                listBox1.Items.Add(g);
            }
            listBox2.Items.Clear();
            foreach (gioco g in giocos)
            {
                listBox2.Items.Add(g);
            }
            listBox3.Items.Clear();
            foreach (gioco g in giocos)
            {
                listBox3.Items.Add(g);
            }
        }


        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                gioco g1 = (new gioco(textBox1.Text, textBox2.Text, int.Parse(textBox3.Text), (tiPiace)comboBox1.SelectedItem));
                giocos.Add(g1);
                aggiorna_lista();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Errore", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                giocos.Remove((gioco)listBox2.SelectedItem);
                aggiorna_lista();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Errore", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                gioco g = ((gioco)listBox2.SelectedItem);
                g.Nome = textBox4.Text;
                aggiorna_lista();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Errore", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}
