﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Giochi
{
    public class gioco
    {
        public enum tiPiace
        {
            brutto,
            normale,
            carino,
            bello,
            bloodborne
        }

        private string nome;
        private string studio;
        private int anno;
        private tiPiace recensione; 

        public string Nome
        {
            get { return nome; }
            set
            {
                if (value.Length < 3 || string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentException("gioco non conosciuto");
                }
                nome = value;
            }
        }
        public string Studio
        {
            get { return studio; }
            set
            {
                if (value.Length < 3 || string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentException("studio non conosciuto");
                }
                studio = value;
            }
        }

        /*
        public string Anno
        {
            get { return anno; }
            set
            {
                if (value.Length < 3 || string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentException("gioco non conosciuto");
                }
                anno = value;
            }
        }
        */

        public int Anno
        {
            get { return anno; }
            set { anno = value; }
        }



        public tiPiace Recensione
        {
            get { return recensione; }
            set { recensione = value; }
        }

        public gioco(string nome, string studio, int anno, tiPiace recensione)
        {
            Nome = nome;
            Studio = studio;
            Anno = anno;
            Recensione = recensione;
        }

        public override string ToString()
        {
            return $"{Nome} uscito nel {Anno} dello studio {Studio} recensione {Recensione}";
        }

    }
}
