﻿namespace Giochi
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tabControl1 = new TabControl();
            tabPage1 = new TabPage();
            comboBox1 = new ComboBox();
            textBox3 = new TextBox();
            textBox2 = new TextBox();
            textBox1 = new TextBox();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            button1 = new Button();
            tabPage2 = new TabPage();
            listBox1 = new ListBox();
            tabPage6 = new TabPage();
            button2 = new Button();
            listBox2 = new ListBox();
            tabPage7 = new TabPage();
            button3 = new Button();
            listBox3 = new ListBox();
            textBox4 = new TextBox();
            tabControl1.SuspendLayout();
            tabPage1.SuspendLayout();
            tabPage2.SuspendLayout();
            tabPage6.SuspendLayout();
            tabPage7.SuspendLayout();
            SuspendLayout();
            // 
            // tabControl1
            // 
            tabControl1.Controls.Add(tabPage1);
            tabControl1.Controls.Add(tabPage2);
            tabControl1.Controls.Add(tabPage6);
            tabControl1.Controls.Add(tabPage7);
            tabControl1.Location = new Point(101, 45);
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new Size(725, 423);
            tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            tabPage1.Controls.Add(comboBox1);
            tabPage1.Controls.Add(textBox3);
            tabPage1.Controls.Add(textBox2);
            tabPage1.Controls.Add(textBox1);
            tabPage1.Controls.Add(label4);
            tabPage1.Controls.Add(label3);
            tabPage1.Controls.Add(label2);
            tabPage1.Controls.Add(label1);
            tabPage1.Controls.Add(button1);
            tabPage1.Location = new Point(4, 24);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new Padding(3);
            tabPage1.Size = new Size(717, 395);
            tabPage1.TabIndex = 0;
            tabPage1.Text = "aggiungi";
            tabPage1.UseVisualStyleBackColor = true;
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Location = new Point(364, 180);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(167, 23);
            comboBox1.TabIndex = 8;
            // 
            // textBox3
            // 
            textBox3.Location = new Point(364, 136);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(167, 23);
            textBox3.TabIndex = 7;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(364, 96);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(167, 23);
            textBox2.TabIndex = 6;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(364, 57);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(167, 23);
            textBox1.TabIndex = 5;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(207, 188);
            label4.Name = "label4";
            label4.Size = new Size(104, 15);
            label4.TabIndex = 4;
            label4.Text = "COME LO REPUTI?";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(207, 144);
            label3.Name = "label3";
            label3.Size = new Size(83, 15);
            label3.TabIndex = 3;
            label3.Text = "ANNO USCITA";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(207, 104);
            label2.Name = "label2";
            label2.Size = new Size(47, 15);
            label2.TabIndex = 2;
            label2.Text = "STUDIO";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(207, 65);
            label1.Name = "label1";
            label1.Size = new Size(82, 15);
            label1.TabIndex = 1;
            label1.Text = "NOME GIOCO";
            // 
            // button1
            // 
            button1.Location = new Point(243, 251);
            button1.Name = "button1";
            button1.Size = new Size(252, 93);
            button1.TabIndex = 0;
            button1.Text = "salva";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // tabPage2
            // 
            tabPage2.Controls.Add(listBox1);
            tabPage2.Location = new Point(4, 24);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new Padding(3);
            tabPage2.Size = new Size(717, 395);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "visualizza";
            tabPage2.UseVisualStyleBackColor = true;
            // 
            // listBox1
            // 
            listBox1.FormattingEnabled = true;
            listBox1.ItemHeight = 15;
            listBox1.Location = new Point(125, 59);
            listBox1.Name = "listBox1";
            listBox1.Size = new Size(476, 289);
            listBox1.TabIndex = 0;
            // 
            // tabPage6
            // 
            tabPage6.Controls.Add(button2);
            tabPage6.Controls.Add(listBox2);
            tabPage6.Location = new Point(4, 24);
            tabPage6.Name = "tabPage6";
            tabPage6.Padding = new Padding(3);
            tabPage6.Size = new Size(717, 395);
            tabPage6.TabIndex = 5;
            tabPage6.Text = "elimina";
            tabPage6.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            button2.Location = new Point(291, 23);
            button2.Name = "button2";
            button2.Size = new Size(149, 45);
            button2.TabIndex = 2;
            button2.Text = "elimina";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // listBox2
            // 
            listBox2.FormattingEnabled = true;
            listBox2.ItemHeight = 15;
            listBox2.Location = new Point(121, 87);
            listBox2.Name = "listBox2";
            listBox2.Size = new Size(476, 289);
            listBox2.TabIndex = 1;
            // 
            // tabPage7
            // 
            tabPage7.Controls.Add(textBox4);
            tabPage7.Controls.Add(button3);
            tabPage7.Controls.Add(listBox3);
            tabPage7.Location = new Point(4, 24);
            tabPage7.Name = "tabPage7";
            tabPage7.Padding = new Padding(3);
            tabPage7.Size = new Size(717, 395);
            tabPage7.TabIndex = 6;
            tabPage7.Text = "modifica";
            tabPage7.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            button3.Location = new Point(391, 21);
            button3.Name = "button3";
            button3.Size = new Size(173, 41);
            button3.TabIndex = 2;
            button3.Text = "modifica";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // listBox3
            // 
            listBox3.FormattingEnabled = true;
            listBox3.ItemHeight = 15;
            listBox3.Location = new Point(123, 85);
            listBox3.Name = "listBox3";
            listBox3.Size = new Size(476, 289);
            listBox3.TabIndex = 1;
            // 
            // textBox4
            // 
            textBox4.Location = new Point(168, 31);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(167, 23);
            textBox4.TabIndex = 6;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(902, 509);
            Controls.Add(tabControl1);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            tabControl1.ResumeLayout(false);
            tabPage1.ResumeLayout(false);
            tabPage1.PerformLayout();
            tabPage2.ResumeLayout(false);
            tabPage6.ResumeLayout(false);
            tabPage7.ResumeLayout(false);
            tabPage7.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private TabControl tabControl1;
        private TabPage tabPage1;
        private TabPage tabPage2;
        private Label label1;
        private Label label4;
        private Label label3;
        private Label label2;
        private TextBox textBox3;
        private TextBox textBox2;
        private TextBox textBox1;
        private Button button1;
        private ListBox listBox1;
        private ComboBox comboBox1;
        private TabPage tabPage6;
        private TabPage tabPage7;
        private ListBox listBox2;
        private ListBox listBox3;
        private Button button2;
        private Button button3;
        private TextBox textBox4;
    }
}
